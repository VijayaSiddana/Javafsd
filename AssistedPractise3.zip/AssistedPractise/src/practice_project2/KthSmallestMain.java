package practice_project2;

public class KthSmallestMain {
	public static void main(String[] args) {
		KthSmallest ob = new KthSmallest(); 
        int arr[] = {11, 4, 8, 6, 4, 20, 24}; 
        int n = arr.length,k = 4; 
        System.out.println("K'th smallest element is "+ ob.kthSmallest(arr, 0, n-1, k)); 
    }	

}
