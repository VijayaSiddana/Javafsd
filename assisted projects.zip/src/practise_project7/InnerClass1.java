package practise_project7;

public class InnerClass1 {

	private String msg="Good Morning"; 
	 
	 class Inner{  
	  void display(){
		  System.out.println(msg+", Have a nice day");
		  }  
	 }  


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClass1 obj=new InnerClass1();
		InnerClass1.Inner in=obj.new Inner();  
		in.display();;  


	}

}

