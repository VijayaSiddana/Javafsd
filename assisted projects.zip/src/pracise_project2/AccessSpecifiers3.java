package pracise_project2;

	public class AccessSpecifiers3 extends proaccessspecifiers {

		public static void main(String[] args) {
			AccessSpecifiers3 obj = new AccessSpecifiers3 ();   
		       obj.display();  
		}

	}


