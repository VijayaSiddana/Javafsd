package pracise_project2;

public class AccessSpecifiers4 {
public static void main(String[] args) {
		
		Pubaccessspecifiers obj = new Pubaccessspecifiers(); 
        obj.display();  
		
	}
}


