package practise_project9;
interface First 
{  
    default void show() 
    { 
        System.out.println("Default First"); 
    } 
} 
interface Last
{  
    default void show() 
    { 
        System.out.println("Default Last"); 
    } 
}  

public class TestClass implements First, Last  {
    public void show() 
    {  
        First.super.show(); 
       Last.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        TestClass ob = new TestClass(); 
        ob.show(); 
    } 

}
