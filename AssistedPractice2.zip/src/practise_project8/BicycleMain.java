package practise_project8;

public class BicycleMain {
    public static void main(String args[])  
    { 
        MountainBike mb = new MountainBike(5, 500, 75); 
        System.out.println(mb.toString());
    } 

}
