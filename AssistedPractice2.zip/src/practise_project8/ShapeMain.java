package practise_project8;

public class ShapeMain {
	
	    public static void main(String[] args) 
	    { 
	        Shape s1 = new Circle("Black", 5.2); 
	        Shape s2 = new Rectangle("Blue", 6, 4);
	        System.out.println(s1.toString()); 
	        System.out.println(s2.toString()); 
	    } 
	}


