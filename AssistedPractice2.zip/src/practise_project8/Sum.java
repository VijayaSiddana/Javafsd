package practise_project8;

public class Sum {
	public int sum(int x, int y) 
    { 
        return (x + y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
        Sum s = new Sum(); 
        System.out.println(s.sum(20, 60)); 
        System.out.println(s.sum(70, 10, 40)); 
        System.out.println(s.sum(20.5, 40.5)); 
    } 

}
